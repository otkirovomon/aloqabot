import telebot
from telebot import types
import sqlite3
from threading import Thread
import time
import re
import json
#import connectID

# Yangi foydalanuvchilarni qo'shish
#users_data = [
#    (648236489, 'none', 'omon', 'none'),
#    (497419788, 'user678', 'Jane', 'Doe'),


#]

#connectID.insert_users_to_all_bots(users_data)







BOTS_DATA = [
    {
        'token': '6724364566:AAG6f4H81sZsrT8iXUpdMmUb3mGdy3iULS4', #instagram
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users1.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6485338949:AAHE1d9Z6edQjFlRhvofoSXABXqsvQcxQLQ', #youtube
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users2.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7051178434:AAGgUPIAxDxjFGJ_cYddtQvYldOVu2khS0s', #tiktok
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users3.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7163349161:AAEUJwFKmI6_FCIvoAimqYNULW6ju74YjPs', #twitter
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users4.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6885319532:AAH8QekIIo0yzHLCJI_d36EA7yaEt5RTChc', #telegram
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users5.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7030810490:AAHyUza0JVoQ6l_vFcEmZMTDkUxbIfmgR0c', #likee
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users6.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6870116160:AAEt7ZNscwKbaMsm8-fahHzB7ziKSxEo4Q8', #chatgpt
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users7.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7165670950:AAE3hDoB7RejZChz8rErZgjiP8zOSKq53x4', #facebook
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users8.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7180115380:AAE2wUkXuTIaiEZ8U3pdH11wiA2mCw4ts48', #googletranslate
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users9.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7116669331:AAEdoKu0PzcWLDYGnOWfAKumsm_v5xz4vao', #amazon
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users10.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7036007288:AAHQyK9tYaQhm33c9WMjJTmzpcn-myaZBdo', #alibaba
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users11.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7091134052:AAFaYzxaNoNjBB2t-8dgriqGQKLrwi2RrBA', #playemarket
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users12.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7003489664:AAGh3_IhLAnXdpeZbBjwAp0dqd-rTv4MWe4', #vkcontact
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users13.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6565891225:AAHNybrbCLBONXQ0zd-HGfMAcLjFSC-kmnE', #snapchat
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users14.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6997357834:AAFs0zztNj9OXK5yNLvpHsfun6GijR6b_bE', #aliexpress
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users15.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6764939580:AAEBHNklsYC_2cVrOt9cAFumUSZ8b-kfdBA', #canva
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users16.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6345601359:AAFAYsXx3mG06wHAA73JY6FzvziGKSXq0do', #tileshop
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users17.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6590640131:AAHqpkHyX_FnU8mVHkzPJVsQYI_TiOXjmfo', #counter
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users18.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6906625514:AAFvpO4qVsZ_9jXDZAVdEbYuMt6u9ujhULE', #bmw_m5
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users19.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6718014898:AAG3T1VrbW_huxEQxIx2C92tJd_QDrRfFbo', #yandex
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users20.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7154977751:AAFa8yUpSMRzxUX3qtKykyBjqmxXPqnnkuc', #netflix
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users21.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7133028138:AAF9RWMNsJs3Mx5Tek-a_YJOwTOSNDPFOpg', #pinterest
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users22.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7092314934:AAF6QqgJea2drHAMwS9Q0mqXRf1zweV6iDU', #threads
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users23.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7079103343:AAFXOsW4D334c_2NpazNrYfmudRb2Tc3-xE', #linkedinn
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users24.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7112201987:AAFP1ecz6ykaktNAJNMQwxca3jwmW7tsvek', #google
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users25.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6644191195:AAFQxMG4VkbP6wmJ2izZsWhpB4NNkldWTsc', #reddit
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users26.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6471755023:AAEwBWrwcfMthxcCnwdClfd2QGHmwAzpesc', #quora
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users27.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7017588999:AAFhFyvUPa3t6mDOFBDVJBfsLU45CV_m1KY', #skype
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users28.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7136429557:AAGrUatoW6uHj1ZOSRJKzvwaxFnO6v2S3Ss', #Imo
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users29.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7130064262:AAHVEmRHuAoUJuQm9LfIRvKvmy-TUT_tnwc', #discord
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users30.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6206452351:AAFwwZ32HmCnaIt7PmJazU2rUtnwiEvjO7k', #picsart
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users31.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6496338291:AAHpcv23IdfXwfABW6ISAsx4axdKcdww8o0', #messenger
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users32.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6646361703:AAGmVuVCv8OiNZo-uO26eZ8HY3xSNlYOGOU', #zoom
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users33.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7167241565:AAHnuMcKWPngU5SbmNBiG3ZNqdeKMLct688', #whatsapp
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users34.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7169834264:AAEYvVy4mWdGcL6vza5KBHdhMj7VHIvdGII', #teams
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users35.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7016958881:AAFlkCpWa9cu8ZgErFN1TiYiPvqv25SKH9w', #OK
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users36.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '5523817382:AAHVYOBcCmleWUSuRBAUKEdIcEXKoTb2Gq4', #@ChatterAs_bot
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users37.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '5589178017:AAEJx5ZfMzWiLYsqdEUz0YCr386KStx7xF4', #@ColoriZatioN_bot
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users38.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '6706508185:AAFo4VKKqLgo_a5NSXn1-raQpOyJX9OcKyM', #Spotify
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users39.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859',
    },
    {
        'token': '7050443080:AAGY5kA5okoWqABfEc65FeqP_DLnMkGn5A4', #Test
        'admin_id': '1542240569',
        'channel_id': '@sadma_dasd_djadnaij_kjaeancka_cl',
        'db_name': 'users40.db',
        'photo_url': 'https://i.postimg.cc/KvP8PqSr/photo-2024-05-15-23-20-28.jpg',
        'check_chat_id': '-1002089310859'
    }
]

def set_up_bot(bot_data):
    bot = telebot.TeleBot(bot_data['token'])
    conn = sqlite3.connect(bot_data['db_name'], check_same_thread=False)
    conn.execute('pragma journal_mode=wal')
    conn.execute('pragma synchronous=normal')

    def execute_query(query, params=(), commit=False):
        with conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            if commit:
                conn.commit()
            return cursor.fetchall()

    execute_query('''
    CREATE TABLE IF NOT EXISTS users (
        chat_id INTEGER PRIMARY KEY,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        start_count INTEGER DEFAULT 0
    )
    ''', commit=True)

    execute_query('''
    CREATE TABLE IF NOT EXISTS sent_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        chat_id INTEGER,
        message_id INTEGER,
        message_type TEXT
    )
    ''', commit=True)

    @bot.message_handler(commands=['start'])
    def start(message):
        chat_id = message.chat.id
        username = message.chat.username or "None"
        first_name = message.chat.first_name or "None"
        last_name = message.chat.last_name or "None"
        user = execute_query("SELECT * FROM users WHERE chat_id = ?", (chat_id,))
        if not user:
            execute_query("INSERT INTO users (chat_id, username, first_name, last_name) VALUES (?, ?, ?, ?)",
                           (chat_id, username, first_name, last_name), commit=True)
            bot.send_message(bot_data['channel_id'], f"New user: {username} (ID: {chat_id}) started the bot.")
        start_markup(message)

    def start_markup(message):
        chat_id = message.chat.id
        first_name = message.chat.first_name or "User"
        markup = types.InlineKeyboardMarkup(row_width=True)
        link_keyboard = types.InlineKeyboardButton(text="Follow", url="https://t.me/DeD_MaS")
        check_keyboard = types.InlineKeyboardButton(text="Check ✅", callback_data="check")
        markup.add(link_keyboard, check_keyboard)
        bot.send_photo(chat_id, bot_data['photo_url'], caption=f"Hi {first_name} 👋 Subscribe to the following channels to use the bot!⤵️", reply_markup=markup)

    @bot.callback_query_handler(func=lambda call: True)
    def callback(call):
        if call.data == 'check':
            check(call)

    def check(call):
        chat_id = call.message.chat.id
        user_id = call.from_user.id
        member_status = bot.get_chat_member(chat_id=bot_data['check_chat_id'], user_id=user_id).status
        if member_status in ['creator', 'administrator', 'member']:
            bot.send_message(chat_id, "Thanks, click /help to use the bot✅")
        else:
            bot.send_message(chat_id, "⬆️Please try again⚠️", reply_markup=start_markup(call.message))

    @bot.message_handler(commands=['help'])
    def help_command(message):
        photo_urls = [
            "https://i.postimg.cc/qvYB098r/photo-2024-05-16-00-41-22.jpg",
            "https://i.postimg.cc/BQmQ78bX/photo-2024-05-16-00-41-19.jpg",
            "https://i.postimg.cc/zfFJW3sz/photo-2024-05-16-01-45-27.jpg",
            "https://i.postimg.cc/rwzyB8Rg/photo-2024-05-16-00-41-26.jpg"
        ]
        media_group = [types.InputMediaPhoto(photo_url) for photo_url in photo_urls]
        bot.send_media_group(message.chat.id, media_group)

    @bot.message_handler(commands=['info'])
    def send_info(message):
        photo_url = "https://i.postimg.cc/gkGZ3Vdp/Picture2.png."

        caption = (
            "- <b>Instagram</b>: Approximately 2.5 billion active users as of 2024.\n"
            "- <b>YouTube</b>: Over 2.7 billion active users as of 2024.\n"
            "- <b>TikTok</b>: Around 1.67 billion active users as of 2024.\n"
            "- <b>Twitter</b>: About 450 million active users as of 2024.\n"
            "- <b>Telegram</b>: Approximately 700 million active users as of 2024.\n"
            "- <b>Likee</b>: Estimated at around 150 million active users.\n"
            "- <b>ChatGPT</b>: This figure varies as it depends on the deployment and specific usage; no exact user count available.\n"
            "- <b>Facebook</b>: Around 3.05 billion active users as of 2024.\n"
            "- <b>Amazon</b>: Over 300 million active users.\n"
            "- <b>Google Translate</b>: Specific user count is not available; used by millions daily.\n"
            "- <b>Alibaba</b>: Approximately 1 billion active users.\n"
            "- <b>Play Market</b>: Over 2.5 billion active users.\n"
            "- <b>ВКонтакте (VK)</b>: Around 100 million active users.\n"
            "- <b>Snapchat</b>: Around 750 million active users.\n"
            "- <b>AliExpress</b>: Approximately 150 million active users.\n"
            "- <b>Canva</b>: Over 100 million active users.\n"
            "- <b>TilesHop</b>: Around 500 million active players.\n"
            "- <b>Counter (Counter-Strike)</b>: Around 24 million active players.\n"
            "- <b>BMW M5</b>: Not applicable as it is a car model, not a platform.\n"
            "- <b>Yandex</b>: Approximately 100 million active users.\n"
            "- <b>Netflix</b>: About 231 million subscribers.\n"
            "- <b>Pinterest</b>: Around 450 million active users.\n"
            "- <b>Threads</b>: Around 100 million active users.\n"
            "- <b>LinkedIn</b>: Over 930 million active users.\n"
            "- <b>Google</b>: Billions of daily users; specific user count for the search engine isn't specified.\n"
            "- <b>Reddit</b>: Around 430 million active users.\n"
            "- <b>Quora</b>: About 400 million active users.\n"
            "- <b>Skype</b>: Approximately 300 million active users.\n"
            "- <b>Imo</b>: Around 200 million active users.\n"
            "- <b>Discord</b>: Over 350 million registered users.\n"
            "- <b>Picsart</b>: Over 150 million active users.\n"
            "- <b>Messenger</b>: Around 988 million active users.\n"
            "- <b>Zoom</b>: About 300 million daily meeting participants.\n"
            "- <b>WhatsApp</b>: Around 2.7 billion active users.\n"
            "- <b>Teams</b>: Over 270 million active users."
        )

        # Split caption into chunks of up to 1024 characters
        captions = [caption[i:i + 1024] for i in range(0, len(caption), 1024)]

        bot.send_photo(message.chat.id, photo=photo_url, caption=captions[0], parse_mode='HTML')

        for part in captions:
            bot.send_message(message.chat.id, part, parse_mode='HTML')

    @bot.message_handler(commands=['admin'])
    def admin(message):
        chat_id = message.chat.id
        if str(chat_id) == bot_data['admin_id']:
            bot.send_message(chat_id, "Here's how you can use this bot:\n- Use /sendall to get started.\n- Use /status_user_id to view this message.\n Users information /get_users_info \n Users chatID Json /get_users_json \n /html")

    @bot.message_handler(commands=['status_user_id'])
    def status_user_id(message):
        if str(message.chat.id) == bot_data['admin_id']:
            total_users = execute_query("SELECT COUNT(*) FROM users")[0][0]
            bot.send_message(message.chat.id, f"Total number of users who have used /start: {total_users}")

    @bot.message_handler(commands=['get_users_info'])
    def get_users_info(message):
        if str(message.chat.id) == bot_data['admin_id']:
            users = execute_query("SELECT * FROM users")
            user_info = "User Information:\n\n"
            for user in users:
                user_info += f"Chat ID: {user[0]}\nUsername: {user[1]}\nFirst Name: {user[2]}\nLast Name: {user[3]}\n\n"
            with open("users_info.txt", "w") as file:
                file.write(user_info)
            with open("users_info.txt", "rb") as file:
                bot.send_document(message.chat.id, file)

    @bot.message_handler(commands=['get_users_json'])
    def get_users_json(message):
        if str(message.chat.id) == bot_data['admin_id']:
            users = execute_query("SELECT chat_id FROM users")
            chat_ids = [{"chat_id": user[0]} for user in users]
            with open("chat_ids.json", "w") as file:
                json.dump(chat_ids, file, indent=4)
            with open("chat_ids.json", "rb") as file:
                bot.send_document(message.chat.id, file)

    def create_dynamic_markup(buttons):
        markup = types.InlineKeyboardMarkup()
        for button in buttons:
            text, url = button
            markup.add(types.InlineKeyboardButton(text, url=url))
        return markup

    @bot.message_handler(commands=['sendall'])
    def handle_sendall(message):
        if str(message.chat.id) == bot_data['admin_id']:
            bot.reply_to(message, "Please send the message you want to broadcast (text, photo, or video).")
            bot.register_next_step_handler(message, get_markup_info)

    def get_markup_info(message):
        bot.reply_to(message, "Please send the markup buttons in the format: [ButtonText1](URL1), [ButtonText2](URL2)")
        bot.register_next_step_handler(message, process_message, message)

    def process_message(message, initial_message):
        buttons = []
        try:
            pattern = re.compile(r'\[(.*?)\]\((.*?)\)')
            matches = pattern.findall(message.text)
            for match in matches:
                text, url = match
                buttons.append((text, url))
        except Exception as e:
            bot.reply_to(message, "Error parsing buttons, please use the format: [ButtonText1](URL1), [ButtonText2](URL2)")
            return

        markup = create_dynamic_markup(buttons)

        users = execute_query("SELECT chat_id FROM users")
        success_count, failed_count = 0, 0

        for user in users:
            try:
                if initial_message.content_type == 'text':
                    message_text = initial_message.text
                    message_text = pattern.sub(r'<a href="\2">\1</a>', message_text)
                    sent_msg = bot.send_message(user[0], message_text, reply_markup=markup, parse_mode='HTML')
                    execute_query("INSERT INTO sent_messages (chat_id, message_id, message_type) VALUES (?, ?, ?)",
                                  (user[0], sent_msg.message_id, 'text'), commit=True)
                elif initial_message.content_type == 'photo':
                    photo = initial_message.photo[-1].file_id
                    caption = initial_message.caption if initial_message.caption else ''
                    caption = pattern.sub(r'<a href="\2\">\1</a>', caption)
                    sent_msg = bot.send_photo(user[0], photo, caption=caption, reply_markup=markup, parse_mode='HTML')
                    execute_query("INSERT INTO sent_messages (chat_id, message_id, message_type) VALUES (?, ?, ?)",
                                  (user[0], sent_msg.message_id, 'photo'), commit=True)
                elif initial_message.content_type == 'video':
                    video = initial_message.video.file_id
                    caption = initial_message.caption if initial_message.caption else ''
                    caption = pattern.sub(r'<a href="\2\">\1</a>', caption)
                    sent_msg = bot.send_video(user[0], video, caption=caption, reply_markup=markup, parse_mode='HTML')
                    execute_query("INSERT INTO sent_messages (chat_id, message_id, message_type) VALUES (?, ?, ?)",
                                  (user[0], sent_msg.message_id, 'video'), commit=True)
                success_count += 1
            except telebot.apihelper.ApiTelegramException as e:
                if e.result_json['description'] == 'Forbidden: bot was blocked by the user':
                    print(f"Bot was blocked by user {user[0]}")
                    execute_query("DELETE FROM users WHERE chat_id = ?", (user[0],), commit=True)
                else:
                    print(f"Failed to send message to {user[0]}: {e}")
                failed_count += 1
        bot.send_message(bot_data['admin_id'], f"Messages sent: {success_count}, Failed: {failed_count}.")

    @bot.message_handler(commands=['deleteall'])
    def handle_delete_all(message):
        if str(message.chat.id) == bot_data['admin_id']:
            messages = execute_query("SELECT chat_id, message_id FROM sent_messages")
            deleted_count = 0
            failed_deletes = 0

            for chat_id, msg_id in messages:
                try:
                    bot.delete_message(chat_id, msg_id)
                    deleted_count += 1
                except telebot.apihelper.ApiTelegramException as e:
                    print(f"Failed to delete message {msg_id} from chat {chat_id}: {e}")
                    failed_deletes += 1

            execute_query("DELETE FROM sent_messages", commit=True)

            bot.send_message(bot_data['admin_id'], f"Deleted messages: {deleted_count}. Failed to delete: {failed_deletes}.")

    @bot.message_handler(commands=['delete'])
    def handle_delete(message):
        if str(message.chat.id) == bot_data['admin_id']:
            bot.reply_to(message, "Please send the ID of the message to delete.")
            bot.register_next_step_handler(message, process_delete)

    def process_delete(message):
        try:
            message_id = int(message.text)
            messages = execute_query("SELECT chat_id, message_id FROM sent_messages WHERE id = ?", (message_id,))
            if not messages:
                bot.reply_to(message, f"No message found with ID {message_id}")
                return

            deleted_count = 0
            failed_deletes = 0

            for chat_id, msg_id in messages:
                try:
                    bot.delete_message(chat_id, msg_id)
                    deleted_count += 1
                except telebot.apihelper.ApiTelegramException as e:
                    print(f"Failed to delete message {msg_id} from chat {chat_id}: {e}")
                    failed_deletes += 1

            execute_query("DELETE FROM sent_messages WHERE id = ?", (message_id,), commit=True)

            bot.send_message(bot_data['admin_id'], f"Deleted message with ID {message_id}. Deleted: {deleted_count}, Failed: {failed_deletes}.")
        except ValueError:
            bot.reply_to(message, "Invalid ID. Please send a valid message ID.")

    @bot.message_handler(commands=['html'])
    def convert_to_html(message):
        if str(message.chat.id) == bot_data['admin_id']:
            bot.reply_to(message, "Please send the text you want to convert to HTML format.")
            bot.register_next_step_handler(message, process_html)

    def process_html(message):
        try:
            text = message.text
            text = re.sub(r'\*(.*?)\*', r'<b>\1</b>', text)  # Bold
            text = re.sub(r'_(.*?)_', r'<i>\1</i>', text)   # Italic
            text = re.sub(r'`(.*?)`', r'<code>\1</code>', text)  # Code
            text = re.sub(r'\~(.*?)\~', r'<s>\1</s>', text)  # Strikethrough
            bot.reply_to(message, f"Converted HTML:\n{text}", parse_mode='HTML')
        except Exception as e:
            bot.reply_to(message, f"Error converting to HTML: {e}")

    while True:
        try:
            bot.polling(none_stop=True)
        except Exception as e:
            print(f"Error occurred: {e}. Restarting bot...")
            time.sleep(10)

threads = []

for bot_data in BOTS_DATA:
    thread = Thread(target=set_up_bot, args=(bot_data,))
    thread.start()
    threads.append(thread)

for thread in threads:
    thread.join()
